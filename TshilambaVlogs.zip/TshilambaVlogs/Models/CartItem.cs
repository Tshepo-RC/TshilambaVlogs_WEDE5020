﻿namespace TshilambaVlogs.Models
{
    public class CartItem
    {
        public string Name { get; set; }

        public decimal Price { get; set; }

        public string Image { get; set; }

        public int Quantity { get; set; } = 1;
    }
}