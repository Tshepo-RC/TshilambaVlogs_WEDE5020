﻿using Microsoft.AspNetCore.Mvc;
using TshilambaVlogs.Models;

namespace TshilambaVlogs.Controllers
{
    public class CartController : Controller
    {
        private static List<CartItem> cart = new List<CartItem>();

        public IActionResult Index()
        {
            return View(cart);
        }

        public IActionResult Add(string name, decimal price, string image)
        {
            var item = cart.FirstOrDefault(x => x.Name == name);

            if (item == null)
            {
                cart.Add(new CartItem
                {
                    Name = name,
                    Price = price,
                    Image = image,
                    Quantity = 1
                });
            }
            else
            {
                item.Quantity++;
            }

            return RedirectToAction("Index");
        }

        public IActionResult Remove(string name)
        {
            var item = cart.FirstOrDefault(x => x.Name == name);

            if (item != null)
                cart.Remove(item);

            return RedirectToAction("Index");
        }
    }
}